#include <map>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <utility>
#include <iostream>
#include <algorithm>
#define LL long long
#define pi 3.1415926535897932384626433
#define sqr(a) ((a)*(a))

using namespace std;

typedef pair<int,int> PII;
const int N=10000001;
int n,k,m;
LL a[N],b[N],ans,X,Y,Z,P,curans;
int myrand(){return ((LL)rand()<<32^(LL)rand()<<16^rand())%1000000000LL;}
void data_maker()
{
    srand(time(0));
    freopen("G.in", "w", stdout);
    int n=1000000;
    for (int Case=1;Case<=10;Case++)
    {
        m=myrand()%n;if (Case==1) m=1;
        P=myrand();
        printf("%d %d %lld\n",n,m,P);
        printf("%d %d %d %d\n",myrand(),myrand(),myrand(),myrand());
        //for (int i=1;i<=n;i++)
        //    if (i<n) printf("%d ",myrand());else printf("%d\n",myrand());
    }
    fclose(stdout);
}
int main()
{
    //data_maker();
    //freopen("G.in", "r", stdin);
    //freopen("G.out", "w", stdout);
    int i,j,k;
    while (scanf("%d%d%lld",&n,&m,&P)!=EOF)
    {
        scanf("%lld%lld%lld%lld",&a[1],&X,&Y,&Z);
        for (i=2;i<=n;i++) a[i]=(a[i-1]*a[i-1]%P*X%P+a[i-1]*Y%P+Z)%P;
        j=0;curans=0;
        for (i=m;i<=n;i++)
        {
            ans=ans*a[i]%P;
            if (i-m+1>j)
            {
                ans=1;
                j=i;
                b[i]=a[i];
                for (k=i-1;k>=i-m+1;k--) b[k]=b[k+1]*a[k]%P;
            }
            curans+=(LL)b[i-m+1]*ans%P;
        }
        printf("%lld\n",curans);
    }
    return 0;
}

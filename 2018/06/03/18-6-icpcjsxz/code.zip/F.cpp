#include <map>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <utility>
#include <iostream>
#include <algorithm>
#define LL long long
#define pi 3.1415926535897932384626433
#define sqr(a) ((a)*(a))

using namespace std;

typedef pair<int,int> PII;
const int N=1000001,P=1000000007;
int n,k,m;
LL ans;
vector<int> g[N];
int fa[N],a[N],fd[N],fu[N];

void data_maker()
{
    srand(time(0));
    freopen("F.in", "w", stdout);
    printf("1\n0\n1\n");
    int n=99999,i;
    printf("%d\n",n);
    printf("0");
    for (i=2;i<=50000;i++) printf(" %d",i-1);
    for (i=50001;i<=99999;i++) printf(" 50000");
    printf("\n");
    for (i=1;i<=n;i++)
        if (i<n) printf("%lld ",(LL)rand()*rand()%1000000+1);
        else  printf("%lld\n",(LL)rand()*rand()%1000000+1);
    n=900000;
    printf("%d\n",n);
    for (i=1;i<=n;i++)
        if (i<n) printf("%lld ",(LL)rand()*rand()%i);
        else  printf("%lld\n",(LL)rand()*rand()%i);
    for (i=1;i<=n;i++)
        if (i<n) printf("%lld ",(LL)rand()*rand()%1000000+1);
        else  printf("%lld\n",(LL)rand()*rand()%1000000+1);
    
    for (int Case=1;Case<=0;Case++)
    {
        printf("%d %d\n",rand()%99+2,rand()%99+2);
    }
    fclose(stdout);
}
void add(int a[],int x,int t)
{
    for (;x<=1000000;x+=x&(-x)) a[x]=a[x]+t;
}
int query(int a[],int x)
{
    int ans=0;
    for (;x;x-=x&(-x)) ans+=a[x];
    return ans;
}
void dfs(int x)
{
    LL tmp=query(fd,a[x]-1);
    add(fd,a[x],1);
    for (auto y:g[x])
    {
        add(fu,a[y],1);
        dfs(y);
        add(fu,a[y],-1);
    }
    ans+=(LL)(query(fd,a[x]-1)-tmp)*(LL)query(fu,a[x]-1);
}
int main()
{
    //data_maker();return 0;
    //freopen("F.in", "r", stdin);
    //freopen("F.out", "w", stdout);
    int i,j;
    while (scanf("%d",&n)!=EOF)
    {
        for (i=1;i<=n;i++) g[i].clear();
        //printf("succ\n");
        for (i=1;i<=n;i++)
        {
            scanf("%d",&fa[i]);
            if (fa[i]>0) g[fa[i]].push_back(i);
        }
        for (i=1;i<=n;i++) scanf("%d",&a[i]);
        memset(fu,0,sizeof(fu));
        memset(fd,0,sizeof(fd));
        ans=0;
        for (i=1;i<=n;i++)
            if (!fa[i])
            {
                add(fu,a[i],1);
                //printf("%d\n",i);
                dfs(i);
                add(fu,a[i],-1);
            }
        printf("%lld\n",ans);
    }
    
    return 0;
}

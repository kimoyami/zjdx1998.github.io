#include <map>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <utility>
#include <iostream>
#include <algorithm>
#define LL long long
#define pi 3.1415926535897932384626433
#define sqr(a) ((a)*(a))

using namespace std;

typedef pair<int,int> PII;
const int N=1000001,P=1000000007;
int n,k;
LL f[N],g[N];


void data_maker()
{
    srand(time(0));
    freopen("D.in", "w", stdout);
    printf("1\n1\n");
    int a[]={0,1,10,100,1000,10000,100000,1000000,10,10000};
    for (int Case=1;Case<=9;Case++)
    {
        vector<int> d;d.clear();
        LL sum=0;
        for (int i=1;i<=1000000;i++)
        {
            int x=(LL)rand()*rand()%a[Case]+1;
            if (sum+x>1000000) break;
            sum+=x;d.push_back(x);
        }
        printf("%d\n",d.size());
        for (int i=0;i<d.size();i++)
            if (i<d.size()-1) printf("%d ",d[i]);else printf("%d\n",d[i]);
    }
    fclose(stdout);
}
LL Pow(LL x,int n)
{
    LL ans=1;
    for (;n;n/=2)
    {
        if (n%2) ans=ans*x%P;
        x=x*x%P;
    }
    return ans;
}
int main()
{
    //data_maker();
    //freopen("D.in", "r", stdin);
    //freopen("D.out", "w", stdout);
    int i,j;
    f[0]=1;for (i=1;i<N;i++) f[i]=f[i-1]*i%P;
    g[N-1]=Pow(f[N-1],P-2);
    for (i=N-2;i>=0;i--) g[i]=g[i+1]*(i+1)%P;
    
    while (scanf("%d",&n)!=EOF)
    {
        LL ans=1,sum=0;
        for (i=1;i<=n;i++)
        {
            int x;scanf("%d",&x);
            sum+=x;
            ans=ans*g[x]%P;
        }
        ans=ans*f[sum]%P;
        printf("%lld\n",ans);
    }
    return 0;
}

#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<set>
#include<vector>
#include<queue>
#include<cstdlib>
#include<ctime>
#include<cassert>
#include<iostream>
using namespace std;
int n,m,i,j,k,s,t,x,y,top,tail;
int a[2010][2010],b[4000010][2];
int main()
{
    //freopen("A.in","r",stdin);
    //double t1=clock();
    while (~scanf("%d%d",&n,&m))
    {
        scanf("%d",&k);
        memset(a,0,sizeof a);
        top=0;
        for (i=1;i<=k;i++)
        {
            scanf("%d%d",&x,&y);
            a[x][y]=1;
            top++;
            b[top][0]=x;b[top][1]=y;
        }
        tail=1;
        while (tail<=top)
        {
            x=b[tail][0];y=b[tail][1];
            if (x-1>0)
            {
                if (a[x-1][y]==0)
                {
                    a[x-1][y]=a[x][y]+1;
                    top++;
                    b[top][0]=x-1;b[top][1]=y;
                }
            }
            if (x+1<=n)
            {
                if (a[x+1][y]==0)
                {
                    a[x+1][y]=a[x][y]+1;
                    top++;
                    b[top][0]=x+1;b[top][1]=y;
                }
            }
            if (y-1>0)
            {
                if (a[x][y-1]==0)
                {
                    a[x][y-1]=a[x][y]+1;
                    top++;
                    b[top][0]=x;b[top][1]=y-1;
                }
            }
            if (y+1<=m)
            {
                if (a[x][y+1]==0)
                {
                    a[x][y+1]=a[x][y]+1;
                    top++;
                    b[top][0]=x;b[top][1]=y+1;
                }
            }
            tail++;
        }
        s=-1;
        x=y=0;
        for (i=1;i<=n;i++)
            for (j=1;j<=m;j++)
                if (a[i][j]>s)
                {
                    s=a[i][j];
                    x=i;
                    y=j;
                }
        printf("%d %d\n",x,y);
    }
    //cout << "std : " << (clock() - t1) / CLOCKS_PER_SEC << endl;
}
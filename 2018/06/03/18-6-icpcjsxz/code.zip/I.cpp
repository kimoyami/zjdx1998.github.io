#include <map>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <utility>
#include <iostream>
#include <algorithm>
#define LL long long
#define pi 3.1415926535897932384626433
#define sqr(a) ((a)*(a))

using namespace std;

typedef pair<int,int> PII;
const int N=101;
int n,k,m,P;
LL a[N][N],b[N][N],tmp[N][N];
int myrand(){return ((LL)rand()<<32^(LL)rand()<<16^rand())%1000000000LL;}
void data_maker()
{
    srand(time(0));
    freopen("I.in", "w", stdout);
    printf("2 1\n1\n");
    int n=100000,m,x;
    for (int Case=1;Case<=9;Case++)
    {
        m=100;
        printf("%d %d\n",n,m);
        for (int i=1;i<=m;i++)
            for (int j=1;j<=m;j++)
            {
                x=myrand()%1000000;if (Case<=4) x%=i^j+(i*j);
                x++;
                if (j<m) printf("%d ",x);else printf("%d\n",x);
            }
    }
    fclose(stdout);
}
void cal(LL c[][N],LL a[][N],LL b[][N])
{
    int i,j,k;
    for (i=1;i<=m;i++)
        for (j=1;j<=m;j++)
            tmp[i][j]=0;
    for (i=1;i<=m;i++)
        for (j=1;j<=m;j++)
            for (k=1;k<=m;k++)
                tmp[i][j]=max(tmp[i][j],a[i][k]+b[k][j]);
    for (i=1;i<=m;i++)
        for (j=1;j<=m;j++)
            c[i][j]=tmp[i][j];
}
void pr(LL a[][N])
{
    printf("\n");
    for (int i=1;i<=m;i++)
        for (int j=1;j<=m;j++)
            if (j<m) printf("%lld ",a[i][j]);else printf("%lld\n",a[i][j]);
}
LL solve(int n)
{
    for (;n;n/=2)
    {
        if (n%2) cal(b,b,a);
        //pr(b);
        cal(a,a,a);
    }
    LL ans=0;
    for (int i=1;i<=m;i++)
        for (int j=1;j<=m;j++)
            if (b[i][j]>ans) ans=b[i][j];
    return ans;
}
int main()
{
    //data_maker();
    //freopen("I.in", "r", stdin);
    //freopen("I.out", "w", stdout);
    int i,j,k;
    while (scanf("%d%d",&n,&m)!=EOF)
    {
        for (i=1;i<=m;i++)
            for (j=1;j<=m;j++)
                scanf("%lld",&a[i][j]),b[i][j]=0;
        printf("%lld\n",solve(n-1));
    }
    return 0;
}

#include <map>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <utility>
#include <iostream>
#include <algorithm>
#define LL long long
#define pi 3.1415926535897932384626433
#define sqr(a) ((a)*(a))

using namespace std;

typedef pair<int,int> PII;
const int N=1000001,P=1000000007;
int n,k,m;
LL f[N],g[N];


void data_maker()
{
    srand(time(0));
    freopen("E.in", "w", stdout);
    printf("2 2\n1000 1000\n");
    for (int Case=1;Case<=98;Case++)
    {
        printf("%d %d\n",rand()%999+2,rand()%999+2);
    }
    fclose(stdout);
}
LL Pow(LL x,int n)
{
    LL ans=1;
    for (;n;n/=2)
    {
        if (n%2) ans=ans*x%P;
        x=x*x%P;
    }
    return ans;
}
LL CC(int n,int m)
{
    return f[n+m-2]*g[m-1]%P*g[n-1]%P;
}
int main()
{
    //data_maker();
    //freopen("E.in", "r", stdin);
    //freopen("E.out", "w", stdout);
    int i,j;
    f[0]=1;for (i=1;i<N;i++) f[i]=f[i-1]*i%P;
    g[N-1]=Pow(f[N-1],P-2);
    for (i=N-2;i>=0;i--) g[i]=g[i+1]*(i+1)%P;
    
    while (scanf("%d%d",&n,&m)!=EOF)
    {
        printf("%lld\n",((CC(n-1,m-1)*CC(n-1,m-1)-CC(n,m-2)*CC(n-2,m))%P+P)%P);
    }
    return 0;
}

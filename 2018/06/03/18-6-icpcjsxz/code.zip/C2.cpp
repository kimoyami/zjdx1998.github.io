#include <bits/stdc++.h>

#define N 100010
#define lb(x) ((x)&(-x))
#define M 7000010
#define l(x) ch[x][0]
#define r(x) ch[x][1]
#define INF 0x3f3f3f3f
#define LL long long
#define debug(x) cout<<#x<<" =  "<<x << endl;

using namespace std;

struct node {
    int l,r;
};

int n,K,totn,cnt;
LL comval;
int val[N],h[N],sum[N],pos[N],rot[N];
int minv[M],ch[M][2];
set<int> st;

void upd(int &x,int y) {
    if(x==-1) x = y;
    else if(y!=-1 && val[pos[y]]<val[pos[x]]) x = y;
}
void add(int x,int v) {
    for(int i=x;i<=n&&i>0;i+=lb(i))
        sum[i] += v;
}
int ask(int x) {
    int ans = 0;
    for(int i=x;i>0;i-=lb(i)) ans+=sum[i];
    return ans;
}
int build(int l,int r) {
    int x = ++totn;
    minv[x] = -1;
    if(l==r) return x;
    int mid = (l+r)>>1;
    l(x) = build(l,mid);
    r(x) = build(mid+1,r);
    return x;
}
int add(int o,int l,int r,int qx) {
    int x = ++totn;
    l(x)=l(o),r(x)=r(o);
    upd(minv[x]=minv[o], qx);
    if(l==r) return x;
    int mid = (l+r)>>1;
    if(qx<=mid) l(x)=add(l(o),l,mid,qx);
    else r(x)=add(r(o),mid+1,r,qx);
    return x;
}
int qs(int x,int l,int r,int ql,int qr) {
    if(ql<=l && r<=qr) return minv[x];
    int mid = (l+r)>>1, ans = -1;
    if(ql<=mid) upd(ans, qs(l(x),l,mid,ql,qr));
    if(mid<qr) upd(ans, qs(r(x),mid+1,r,ql,qr));
    return ans;
}
void del(int x,int l,int r,int qx,int qt) {
    if(l==r){
        minv[x] = qt>0? -1:l;
        return;
    }
    int mid = (l+r)>>1;
    if(qx<=mid) del(l(x),l,mid,qx,qt);
    else del(r(x),mid+1,r,qx,qt);
    minv[x] = minv[l(x)];
    upd(minv[x], minv[r(x)]);
}

vector<node> tp;

bool dfs(int t,LL now,int dep) {
    if(now < comval) return 0;
    cnt++;
    if(cnt >= K) return 1;
    if(t==n || dep==18) return 0;
    tp.clear();
    vector<node> nex;
    int l = 1,r;
    for(auto ii=st.begin();ii!=st.end();ii++) {
        tp.push_back((node){l,*ii});
        l = *ii;
    }
    tp.push_back((node){l,n});
    reverse(tp.begin(),tp.end());
    int cntnow = 0;
    for(int i=0;i<(int)tp.size();i++) {
        l=tp[i].l;
        r=tp[i].r;
        int tt;
        while(tt = qs(rot[t+1],1,n,l,r), tt!=-1) {
            if(now-val[pos[tt]]+i < comval) break;
            cntnow++;
            nex.push_back((node){tt,-val[pos[tt]]+i});
            del(rot[t+1],1,n,tt,1);
            if(cntnow+cnt>=K) break;
        }
    }
    for(auto p:nex) del(rot[t+1],1,n,p.l,-1);
    for(auto p:nex) {
        st.insert(p.l);
        if(dfs(pos[p.l], now+p.r,dep+1)) return 1;
        st.erase(p.l);
    }
    /*for(int j=t+1;j<=n;j++)
     {
     add(h[j],1);
     if(dfs(j, now-val[j]+ask(n) - ask(h[j]),dep+1)) return 1;
     add(h[j],-1);
     }*/
    return 0;
}
int main () {
    //	freopen("C.in","r",stdin);
    while(cin >> n >> K) {
        LL l=0,r=0;
        for(int i=1;i<=n;i++) scanf("%d",&h[i]), sum[i]=0, pos[h[i]]=i;
        for(int i=1;i<=n;i++) val[i] = ask(n)-ask(h[i]), add(h[i],1);
        for(int i=1;i<=n;i++) sum[i]=0;
        for(int i=n;i>=1;i--) val[i] += ask(h[i]-1), add(h[i],1);
        for(int i=1;i<=n;i++) r+=val[i];
        r>>=1;
        LL rr = r;
        totn = 0;
        rot[n+1]=build(1,n);
        for(int i=n;i>=1;i--) rot[i]=add(rot[i+1],1,n,h[i]);
        while(r-l>3) {
            comval=(l+r)>>1;
            st.clear();
            cnt = 0;
            for(int i=1;i<=n;i++) sum[i] = 0;
            if(dfs(0,rr,0)) l=comval;
            else r=comval;
        }
        for(LL i=r;i>=l;i--) {
            comval = i;
            st.clear();
            cnt = 0;
            for(int j=1;j<=n;j++) sum[j] = 0;
            if(dfs(0,rr,0)) {
                cout << i << endl;
                break;
            }
        }
    }
    return 0;
}
/*
 10 144
 2 10 5 3 7 9 1 8 4 6 
 */
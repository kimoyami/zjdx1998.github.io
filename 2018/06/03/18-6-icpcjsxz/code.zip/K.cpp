#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <ctime>
#define LL long long
#define pi 3.1415926535897932384626433

using namespace std;

const int maxn = 105;
const int inf  = 100000000;
const int base = 1000000007;

int g[maxn][maxn], f[maxn][maxn];
int fa[maxn];
vector<string> init;

class TreesCount
{
public:
    int count(vector <string>);
}G;
int myrand(){return ((LL)rand()<<32^(LL)rand()<<16^rand())%1000000000LL;}
void data_maker()
{
    srand(time(0));
    freopen("K.in", "w", stdout);
    printf("1\n0\n");
    int n=100,m,i,j,f[101][101],fa[101];
    for (int Case=1;Case<=99;Case++)
    {
        for (i=1;i<=n;i++) f[i][i]=0;
        for (i=1;i<=n;i++)
            for (j=i+1;j<=n;j++)
                f[i][j]=f[j][i]=rand()%10;
        for (i=2;i<=n;i++)
            fa[i]=rand()%(i-1)+1,f[i][fa[i]]=f[fa[i]][i]=rand()%9+1;
        printf("%d\n",n);
        for (i=1;i<=n;i++)
            for (j=1;j<=n;j++)
                if (j<n) printf("%d",f[i][j]);else printf("%d\n",f[i][j]);
    }
    fclose(stdout);
}
int TreesCount::count(vector <string> graph)
{
    int n = graph.size();
    for (int i = 0; i < n; i ++)
        for (int j = 0; j < n; j ++)
        {
            g[i][j] = graph[i][j] - 48;
            if (! g[i][j]) g[i][j] = inf;
            f[i][j] = g[i][j];
        }
    //floyd
    for (int k = 0; k < n; k ++)
        for (int i = 0; i < n; i ++)
            for (int j = 0; j < n; j ++)
                if (i != k && i != j && j != k)
                    g[i][j] = min(g[i][j], g[i][k] + g[k][j]);
    //insert
    g[0][0] = 0;
    memset(fa, 0, sizeof(fa));
    for (int i = 0; i < n; i ++)
        for (int j = 0; j < n; j ++)
            if (i != j && g[0][i] + f[i][j] == g[0][j])
                fa[j] ++;
    int ans = 1;
    for (int i = 1; i < n; i ++)
        ans = ((LL) ans * (LL) fa[i]) % (LL) base;
    return ans;
}

int main()
{
    //data_maker();
    //freopen("K.in", "r", stdin);
    //freopen("K.out", "w", stdout);
    int n;
    while (scanf("%d",&n)!=EOF)
    {
    init.clear();
    for (int i = 1; i <= n; i ++)
    {
        string s; cin >> s;
        init.push_back(s);
    }
    cout << G.count(init) << endl;
    }
    return 0;
}
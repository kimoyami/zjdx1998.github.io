#include<bits/stdc++.h>
using namespace std;
int n,m,i,j,k,t;
int a[110][310];
int main()
{
    a[1][1]=1;
    a[2][1]=5;
    for (i=3;i<=100;i++)
    {
        t=i*i;
        for (j=1;j<=300;j++) a[i][j]=a[i-2][j];
        a[i][1]++;
        for (j=1;j<=300;j++) a[i][j]*=t;
        for (j=1;j<=300;j++) a[i][j]+=a[i-1][j];
        for (j=1;j<300;j++)
        {
            a[i][j+1]+=a[i][j]/10;
            a[i][j]%=10;
        }
    }
    while(~scanf("%d",&n))
    {
        k=300;
        while (a[n][k]==0) k--;
        for (i=k;i>=1;i--) printf("%d",a[n][i]);
        puts("");
    }
}
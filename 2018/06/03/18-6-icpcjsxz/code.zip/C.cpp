#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<set>
#include<vector>
#include<queue>
#include<cstdlib>
#include<ctime>
#include<cassert>
#include<iostream>

using namespace std;

typedef long long LL;
typedef pair<int,int> PII;
const int N=100002,INF=(1<<29);
struct JS{int c[2],min;}F[40*N];
set<PII> s;

int i,j,n,m,num,x,y,cnt;
int a[N],b[N],f[N],root[N],c[N],d[N];
LL ql,qr,mid,ans,R;

int myrand(){return ((LL)rand()<<32^(LL)rand()<<16^rand())%1000000000LL;}
void data_maker()
{
    srand(time(0));
    freopen("C.in", "w", stdout);
    int n=10000,m,x,a[N];
    for (int Case=1;Case<=10;Case++)
    {
        LL m=10000;
        if (n<=17) m=min(m,(LL)(1<<n));
        printf("%d %lld\n",n,myrand()%m+1);
        for (int i=1;i<=n;i++)
            if (Case%2) a[i]=i; else a[i]=n+1-i;
        int t;if (Case<=4) t=1000;else t=n;
        for (int i=1;i<=t;i++)
        {
            int x=myrand()%n+1,y=myrand()%n+1,t;
            t=a[x];a[x]=a[y];a[y]=t;
        }
        for (int i=1;i<=n;i++) if (i<n) printf("%d ",a[i]);else printf("%d\n",a[i]);
    }
    fclose(stdout);
}
void init()
{
    for (i=1;i<=n;i++) scanf("%d",&a[i]),c[a[i]]=i;
    root[n+1]=0;
    num=0;F[0].min=0;b[0]=INF;
    //memset(F,0,sizeof(F));
    ql=qr=0;
}
void pre()
{
    for (i=1;i<=n;i++) b[i]=f[i]=0;
    for (i=1;i<=n;i++)
    {
        for (x=a[i];x<=n;x+=x&(-x)) b[a[i]]+=f[x],qr=qr+(LL)f[x];
        for (x=a[i];x;x-=x&(-x)) f[x]+=1;
    }
    for (i=1;i<=n;i++) f[i]=0;
    for (i=n;i>=1;i--)
    {
        for (x=a[i];x;x-=x&(-x)) b[a[i]]+=f[x];
        for (x=a[i];x<=n;x+=x&(-x)) f[x]+=1;
    }
}
int MIN(int x,int y){if (b[x]<b[y]) return x;else return y;}
int insert(int k,int l,int r,int x)
{
    int cur=++num;F[cur]=F[k];
    
    if (l==r) F[cur].min=x;
    else
    {
        int mid=(l+r)/2;
        if (x<=mid) F[cur].c[0]=insert(F[cur].c[0],l,mid,x);
            else F[cur].c[1]=insert(F[cur].c[1],mid+1,r,x);
        F[cur].min=MIN(F[F[cur].c[0]].min,F[F[cur].c[1]].min);
    }
   // printf("%d:[%d,%d]:%d,%d,%d\n",cur,l,r,F[cur].c[0],F[cur].c[1],F[cur].min);
    return cur;
}
int query(int k,int l,int r,int L,int R)
{
    if (k==0) return 0;
    if (L<=l&&r<=R) return F[k].min;
    int mid=(l+r)/2,ans=0;
    if (L<=mid) ans=MIN(ans,query(F[k].c[0],l,mid,L,R));
    if (R>mid) ans=MIN(ans,query(F[k].c[1],mid+1,r,L,R));
    return ans;
}
void change(int k,int l,int r,int x,int ax)
{
    if (l==r) {F[k].min=ax;return;}
    int mid=(l+r)/2;
    if (x<=mid) change(F[k].c[0],l,mid,x,ax);
        else change(F[k].c[1],mid+1,r,x,ax);
    F[k].min=MIN(F[F[k].c[0]].min,F[F[k].c[1]].min);
}
int get(int x)
{
    int ans=0;
    for (;x<=n;x+=x&(-x)) ans+=f[x];
    return ans;
}
vector<int>rua;
void del(int x)
{
    rua.push_back(x);
    for (y=x;y;y-=y&(-y)) f[y]++;
    set<PII>::iterator it=s.lower_bound({x,n+1});
    it--;
    PII t=*it;
    s.erase(t);
    if (t.first==t.second) return;
    if (t.first<x) s.insert({t.first,x-1});
    if (x<t.second) s.insert({x+1,t.second});
}
void ins(int x)
{
    rua.pop_back();
    for (y=x;y;y-=y&(-y)) f[y]--;
    if (s.size()==0){s.insert({x,x});return;}
    set<PII>::iterator it=s.lower_bound({x,n});
    PII a,b;
    if (it==s.end())
    {
        it--;
        a=*it;
        if (x==a.second+1) s.erase(a),s.insert({a.first,x});
            else s.insert({x,x});
        return;
    }
    if (it==s.begin())
    {
        b=*it;
        if (x==b.first-1) s.erase(b),s.insert({x,b.second});
        else s.insert({x,x});
        return;
    }
    b=*it;it--;a=*it;
    if (x!=a.second+1&&x!=b.first-1) {s.insert({x,x});return;};
    if (x==a.second+1&&x==b.first-1) {s.erase(a);s.erase(b);s.insert({a.first,b.second});return;};
    if (x==a.second+1) {s.erase(a);s.insert({a.first,x});return;}
        else {s.erase(b);s.insert({x,b.second});return;};
}
struct cmp {
    bool operator () (const PII x,const PII y) {
        return b[x.first]-d[x.second]>b[y.first]-d[y.second];
    }
};
priority_queue<PII,vector<PII>,cmp> q;
vector<PII> cal_list(int cur,LL res)
{
    int i,len,x;
    //q.clear();
    while (!q.empty()) q.pop();
    
    vector<PII> a,ans;
    for (auto x:s) a.push_back(x);
    len=(int)a.size();
    for (i=0;i<len;i++) d[i]=get(a[i].first);
    for (i=0;i<len;i++)
    {
        x=query(root[cur+1],1,n,a[i].first,a[i].second);
        if (x>0) q.push({x,i});
    }
    for (;;)
    {
        if (q.empty()||m-cnt<=ans.size()) break;
        PII t=q.top();q.pop();
        if (b[t.first]-d[t.second]>res) break;
        else
        {
            change(root[cur+1],1,n,t.first,0);
            ans.push_back({t.first,b[t.first]-d[t.second]});
            x=query(root[cur+1],1,n,a[t.second].first,a[t.second].second);
            if (x>0) q.push({x,t.second});
        }
    }
    for (auto t:ans) change(root[cur+1],1,n,t.first,t.first);
    return ans;
}
int vis=0;
void check(int cur,LL res)
{
    //int v[10];memset(v,0,sizeof(v));
    //for (auto x:rua) v[x]=1;
    //for (i=1;i<=n;i++) if (v[a[i]]==0) printf("%d ",a[i]);printf(":%lld\n",res);

    
    
    if (cnt>=m||cur==n||s.size()>17) return;
   // if (v[2]==1&&v[3]==1&&mid==1)
   // {
   //     mid=1;
        //  for (auto x:q) printf("*%d\n",x.first);
   // }
    //++vis;
    //printf("%d %lld %d\n",cur,res,++vis);
    vector<PII> q=cal_list(cur,res-mid);

   // if (q.size()==0) printf("*\n");
   // assert(s.size()>20);
    for (auto x:q)
    {
        //assert(x.second>=0);
        cnt++;
        del(x.first);
        check(c[x.first],res-x.second);
        
        ins(x.first);
    }
}
void work()
{
    R=qr;
   // printf("%lld\n",R);
    s.clear();
    s.insert({1,n});
    memset(f,0,sizeof(f));
    while (ql<=qr)
    {
        mid=(ql+qr)/2;
        
        cnt=1;
        //s.clear();
        vis=0;
     //   printf("%lld:\n",mid);
        check(0,R);
        //printf("%lld %d\n",mid,vis);
        if (cnt>=m) ans=mid,ql=mid+1;else qr=mid-1;
    }
    printf("%lld\n",ans);
}
void cal2()
{
    int i,j,k,x;
    vector<LL> ans;
    for (k=0;k<(1<<n);k++)
    {
        LL cur=0;
        for (i=1;i<=n;i++) f[i]=0;
        for (i=1;i<=n;i++)
            if ((k&(1<<(i-1)))>0)
        {
            //printf("%d ",a[i]);
            for (x=a[i];x<=n;x+=x&(-x)) cur+=f[x];
            for (x=a[i];x;x-=x&(-x)) f[x]++;
        }
        //printf(":%d\n",cur);
        ans.push_back(cur);
    }
    sort(ans.rbegin(),ans.rend());
    for (auto x:ans) printf("%lld ",x);printf("\n");
    printf("%lld\n",ans[m-1]);
}
int main()
{
    //data_maker();
   // freopen("C.in","r",stdin);
   // freopen("C.out","w",stdout);
   // double t1=clock();
    while (scanf("%d%d",&n,&m)!=EOF)
    {
        init();
        pre();
        for (i=n;i>=1;i--) root[i]=insert(root[i+1],1,n,a[i]);
        //printf("succ\n");
      // for (i=0;i<=num;i++) printf("%d:%d,%d,%d\n",i,F[i].c[0],F[i].c[1],F[i].min);
        work();
       // cal2();
    }
    //cout << "std : " << (clock() - t1) / CLOCKS_PER_SEC << endl;
}
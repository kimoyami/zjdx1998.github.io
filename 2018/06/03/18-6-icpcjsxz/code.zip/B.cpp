#include <map>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <utility>
#include <iostream>
#include <algorithm>
#define LL long long
#define pi 3.1415926535897932384626433
#define sqr(a) ((a)*(a))

using namespace std;

typedef pair<int,int> PII;
typedef pair<PII,int> PIII;
const int N=5002,P=1000000007;
int f[2][N];
int ans[N];
vector<PIII> d;

void data_maker()
{
    srand(time(0));
    freopen("B.in", "w", stdout);
    printf("1 0\n1 1\n1 5000\n5000 5000\n");
    for (int Case=1;Case<=4996;Case++)
    {
        printf("%d %d\n",rand()%5000+1,rand()%5001);
    }
    fclose(stdout);
}
int main()
{
    //data_maker();
    //freopen("B.in", "r", stdin);
    //freopen("B.out", "w", stdout);
    
    int i,j,k,x,y,Case=0,cur=0;
    while (scanf("%d%d",&x,&y)!=EOF) d.push_back({{x,y},++Case});
    sort(d.begin(),d.end());
    f[1][0]=1;f[1][1]=-1;k=1;
    for (i=1;i<=5000;i++,k^=1)
    {
        for (j=0;j<=5000;j++)
        {
            if (j>0) f[k][j]=(f[k][j]+f[k][j-1])%P;
            f[k^1][j]=(f[k^1][j]+f[k][j])%P;
            if (i+j+1<=5000)
                f[k^1][i+j+1]=((f[k^1][i+j+1]-f[k][j])%P+P)%P;
        }
        while (cur!=Case&&i==d[cur].first.first)
            ans[d[cur].second]=f[k][d[cur].first.second],++cur;
        memset(f[k],0,sizeof(f[k]));
    }
    
    for (i=1;i<=Case;i++) printf("%d\n",ans[i]);
    
    return 0;
}

#include<iostream>
#include<stdexcept>
using namespace std;
#define rep(i,n) for(int i=1;i<=n;i++)

class testE : public runtime_error{
public:
    testE(const string& message)
    :runtime_error( message ){}
};

int main(){
    try{
        throw testE("Test the order of Exception catchers");
    }catch(testE & A){
        cout<<"testE was caught\n" << A.what()<<endl; 
    }catch(runtime_error& B){
        cout<<"runtime_error was caught\n" << B.what()<<endl;
    }
    cout<<"--------------Now we change the order---------------\n";
    try{
        throw testE("Test the order of Exception catchers");
    }catch(runtime_error& B){
        cout<<"runtime_error was caught\n" << B.what()<<endl;
    }catch(testE & A){
        cout<<"testE was caught\n" << A.what()<<endl; 
    }
    return 0;
}
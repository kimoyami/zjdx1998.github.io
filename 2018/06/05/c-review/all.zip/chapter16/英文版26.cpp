#include<iostream>
#include<typeinfo>
using namespace std;
#define rep(i,n) for(int i=1;i<=n;i++)

class Points{
public:
    Points();
    Points(int a,int b):x(a),y(b){};
private:
    int x,y;
};

template<typename T>
void try_fun(T a){
    try{
        throw a;
    }catch(...){
        cout<<"now we catch the "<<typeid(a).name()<<endl;
    }
}

int main(){
    cout<<"Test Int"<<endl;
    try_fun(1);
    cout<<"Test double"<<endl;
    try_fun(1.0);
    cout<<"Test string"<<endl;
    try_fun("String");
    cout<<"Test class"<<endl;
    Points cls(5,6);
    try_fun(cls);
    return 0;
}
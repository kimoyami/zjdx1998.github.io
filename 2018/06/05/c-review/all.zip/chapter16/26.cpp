#include<iostream>
using namespace std;
#define rep(i,n) for(int i=1;i<=n;i++)

template<typename T>
void fun_try(T a){
    try{
        throw a<2.0 ? a : 2.0;
    }catch(double){
        cout<<"Double throw!"<<endl;
    }catch(int){
        cout<<"Int throw!"<<endl;
    }
}

int main(){
    cout<<"Now we test int"<<endl;
    fun_try(1);
    cout<<"Now we test double"<<endl;
    fun_try(1.0);
    return 0;
}
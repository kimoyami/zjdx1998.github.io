#include <iostream>
#include "Employee.h"
using namespace std;

Employee::Employee( const string &fname, const string &lname,const string &ssn, 
                    int month, int day, int year )
   : firstName( fname ), lastName( lname ), socialSecurityNumber( ssn ),
     birthDate( month, day, year ){} 

void Employee::setFirstName( const string &fname ){
   firstName = fname;
} 

string Employee::getFirstName() const{
   return firstName;
} 

void Employee::setLastName( const string &lname ){
   lastName = lname;
} 

string Employee::getLastName() const{
   return lastName;
} 

void Employee::setSocialSecurityNumber( const string &ssn ){
   socialSecurityNumber = ssn; 
} 

string Employee::getSocialSecurityNumber() const{
   return socialSecurityNumber;
} 

void Employee::setBirthDate( int month, int day, int year ){
   birthDate.setDate( month, day, year );
} 

Date Employee::getBirthDate() const{
   return birthDate;
} 

void Employee::print() const{
   cout << getFirstName() << ' ' << getLastName()
      << "\nsocial security number: " << getSocialSecurityNumber()
      << "\nbirthday: " << getBirthDate();
} 


#include<bits/stdc++.h>
#include "Account.h"
#include "SavingsAccount.h"
#include "CheckingAccount.h"
using namespace std;

int main() {
    vector < Account * > accounts( 4 );

    accounts[0] = new SavingsAccount(100.0, 0.01);
    accounts[1] = new CheckingAccount(100.0, 0.02);
    accounts[2] = new SavingsAccount(100.0, 0.03);
    accounts[3] = new CheckingAccount(100.0, 0.04);

    cout << fixed << setprecision(2);
    vector<Account*>::iterator iter;
    for (iter = accounts.begin(); iter != accounts.end(); iter++) {
        int i = iter - accounts.begin();
        cout << "Account " <<i+1<< " balance is: $" << accounts[i]->getBalance() << endl;

        double wdnum = 0.0;
        cout << "Please enter an amount to withdraw from Account " << i + 1 << ": ";
        cin >> wdnum;
        accounts[i]->debit(wdnum);

        double dpnum = 0.0;
        cout << "Please enter an amount to deposit into Account " << i + 1 << ": ";
        cin >> dpnum;
        accounts[i]->credit(dpnum);

        SavingsAccount *sAPtr = dynamic_cast <SavingsAccount *> (accounts[i]);

        if ( sAPtr != 0 ) {
            double interestEarned = sAPtr->calculateInterest();
            cout << "Adding $" << interestEarned << " interest to Account "
                 << i + 1 << " (a SavingsAccount)" << endl;
            sAPtr->credit(interestEarned);
        }

        cout << "Now Account " << i + 1 << "balance is: $" << accounts[i]->getBalance() << endl;
    }
}
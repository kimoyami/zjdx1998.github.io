#ifndef SACCOUNT_H
#define SACCOUNT_H
#include "Account.h"
class SavingsAccount : public Account{
public:
    SavingsAccount(double nbalance,double irate);
    double calculateInterest();
private:
    double interestrate;
};
#endif

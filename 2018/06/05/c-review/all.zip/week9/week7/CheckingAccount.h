#ifndef CACCOUNT_H
#define CACCOUNT_H
#include "Account.h"
class CheckingAccount : public Account{
public:
    CheckingAccount(double nbalance,double nfee);
    void credit(double);
    void debit(double);
    void minusfee();
private:
    double fee;
};

#endif

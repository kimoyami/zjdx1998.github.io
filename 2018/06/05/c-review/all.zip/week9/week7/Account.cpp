#include "Account.h"
#include<cstdio>
#include<iostream>
using namespace std;
Account::Account(double nbalance):balance(nbalance){
    if(nbalance<0){
        puts("Initial balance cannot be negative.");
        balance=0;
    }
}

void Account::credit(double pbalance){setBalance(getBalance()+pbalance);}

bool Account::debit(double dbalance){
    if(getBalance()<dbalance) {
        puts("Debit amount exceeded account balance");
        return false;
    }
    setBalance(getBalance()-dbalance);
    return true;
}

double Account::getBalance(){return balance;}

void Account::setBalance(double balance){
    this->balance=balance;
}

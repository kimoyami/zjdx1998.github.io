#include "SavingsAccount.h"

SavingsAccount::SavingsAccount(double nbalance,double irate)
    :Account(nbalance){
        if(irate<0) irate=0;
        interestrate = irate;
    }

double SavingsAccount::calculateInterest(){
    return interestrate * getBalance();
}

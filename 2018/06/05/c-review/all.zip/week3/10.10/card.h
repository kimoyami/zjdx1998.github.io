#ifndef CARD_H
#define CARD_H
#include<ctime>
#include<vector>
#include<cstdio>
#include<string>
#include<cstdlib>
#include<cstring>
#include<iostream>
#define rep(i,n) for(int i=1;i<=n;i++)
using namespace std;
#endif

class Card{
public:
    Card(int,int);
    string toString();
private:
    int face,suit; // represent value & color
    static string faces[14];
    static string suits[5];
};

class DeckOfCards{
public:
    DeckOfCards();
    void shuffle();
    bool moreCards();
    Card dealCard();
private:
    int currentCard;
    vector<Card> deck;
};
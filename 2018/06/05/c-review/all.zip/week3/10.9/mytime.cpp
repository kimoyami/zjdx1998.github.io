#ifndef MYTIME_CPP
#define MYTIME_CPP
#include<cstdio>
#include<iomanip>
#include<iostream>
using namespace std;

int Time::getHour() const{
    return cntSecond / 3600;
}

int Time::getMinute() const{
    return (cntSecond % 3600) / 60;
}

int Time::getSecond() const{
    return cntSecond % 60;
}

Time::Time(int hour,int minute,int second){
    setTime(hour,minute,second);
}

Time& Time::setTime(int hour,int minute,int second){
    cntSecond = hour * 3600 + minute * 60 + second;
}

Time& Time::setHour(int hour){
    setTime(hour,getMinute(),getSecond());
    return *this;
} 

Time& Time::setMinute(int minute){
    setTime(getHour(),minute,getSecond());
    return *this;
}

Time& Time::setSecond(int second){
    setTime(getHour(),getMinute(),second);
    return *this;
}

void Time::printUniversal() const{
    cout<< setfill('0')<<setw(2)<<getHour()<<":"
        << setw(2)<<getMinute()<<":"<<setw(2)<<getSecond();
    cout<<endl;    
}

void Time::printStandard() const{
    int hour = getHour();
    cout << ( (hour==0) || (hour==12 ) ? 12 : hour%12)<<":"
         << setfill('0')<<setw(2)<<getMinute()<<":"<<setw(2)
         <<getSecond()<< (hour < 12 ? "AM" : "PM");
    cout<<endl;    
}
#endif
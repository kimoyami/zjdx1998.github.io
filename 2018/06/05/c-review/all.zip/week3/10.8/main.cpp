#include "integerset.cpp"

int main(){
    int A[5]={1,2,3,4,5};
    IntegerSet S1(A,5);
    IntegerSet S2(A,5);
    if(S1.isEqualTo(S2)) printf("Equivalent!\n");
    S1.insertElement(6);
    puts("after inserting 6");
    if(!S1.isEqualTo(S2)) printf("Not Equivalent!\n");
    IntegerSet C;
    puts("unionOfSet1 & 2:");
    C = IntegerSet::unionOfSets(S1,S2);
    C.printSet();
    puts("intersectionOfSet1 & 2:");
    C = IntegerSet::intersectionOfSets(S1,S2);
    C.printSet();
    return 0;
}
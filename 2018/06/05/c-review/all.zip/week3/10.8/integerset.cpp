#ifndef CD_H
#define CD_H
#include "integerset.h"
#include <cstdio>
#include <cstring>
#endif
IntegerSet::IntegerSet(){
    memset(s,false,sizeof(s));
}

void IntegerSet::errorPrint() const{
    puts("RANGE OUT! Please check the nubmer!");
}

IntegerSet::IntegerSet(int a[],int size){
    memset(s,false,sizeof(s));
    for(int i=0;i<size;i++)
        if(a[i]>100||a[i]<0) errorPrint();
        else                 insertElement(a[i]);
}
IntegerSet IntegerSet::unionOfSets(IntegerSet A,IntegerSet B){
    IntegerSet C;
    for(int i=0;i<=100;i++)
        if(A.s[i]||B.s[i]) C.insertElement(i);
    return C;
}

IntegerSet IntegerSet::intersectionOfSets(IntegerSet A,IntegerSet B){
    IntegerSet C;
    for(int i=0;i<=100;i++)
        if(A.s[i]&&B.s[i]) C.insertElement(i);
    return C;
}

void IntegerSet::printSet() const{ 
    for(int i=0;i<=100;i++)
        if(s[i]) printf("%d ",i);
    printf("\n");
}

bool IntegerSet::isEqualTo(IntegerSet &A) const{
    for(int i=0;i<=100;i++)
        if(A.s[i]!=s[i]) return false;
    return true;
}

void IntegerSet::insertElement(int k){
    s[k]=true;
}

void IntegerSet::deleteElement(int k){
    s[k]=false;
}
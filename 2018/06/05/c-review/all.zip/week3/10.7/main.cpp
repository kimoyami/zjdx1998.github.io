#include "savingsaccount.cpp"


int main(){
    SavingsAccount saver1(2000.00,0.03);
    SavingsAccount saver2(3000.00,0.03);    
    saver1.calculateMonthlyInterest();
    saver2.calculateMonthlyInterest();
    saver1.Print();
    saver2.Print();
    SavingsAccount::modifyInterestRate(0.04);
    saver1.calculateMonthlyInterest();
    saver2.calculateMonthlyInterest();
    saver1.Print();
    saver2.Print();
    return 0;
}
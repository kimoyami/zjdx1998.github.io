#ifndef S_CPP
#define S_CPP
#include <cstdio>
#include "savingsaccount.h"
#endif

double SavingsAccount::annualInterestRate = 0;

void SavingsAccount::modifyInterestRate(double newInterestRate){
    annualInterestRate = newInterestRate;
}    

void SavingsAccount::calculateMonthlyInterest(){
    savingsBalance += savingsBalance * annualInterestRate / 12;
}

void SavingsAccount::Print() const{
    printf("The interest will be %.3lf\n",savingsBalance);
}

SavingsAccount::SavingsAccount(double nowBalance,double nowInterestRate){
    annualInterestRate = nowInterestRate;
    savingsBalance = nowBalance;
}
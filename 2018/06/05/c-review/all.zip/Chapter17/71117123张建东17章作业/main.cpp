#include "Assistant.h"
#include "Teacher.h"
#include "master.h"
#include <map>
#include <fstream>
int iosin;
map<int,BaseProperty*> maps;
ofstream finfo("info.txt",ios::out);
ofstream flog("log.txt",ios::out);
void Solve(istream& fin){
    if(iosin==1){
        cout<<"Please Enter in the following format!"<<endl;
        cout<<"If you want to write in something,Please Enter 'Write'(without quotation) first."<<endl;
        cout<<"If you want to query the information, please enter Query + CardId(without +)"<<endl;
        cout<<"If you enter 'write', then please write the identity like Assistant/Teacher/Master"<<endl;
        cout<<"Then Enter CardID Name Birthday(YY/MM/DD) School(Teacher) or Major(Master) or Project(Assistant)"<<endl;
        cout<<"Then Enter Domain(Teacher) or MasterProject(Master),then enter Course(Teacher or Master)"<<endl;
        flog<<"===================Query Log Here=====================\n"<<endl;
    }
    string kind;
    while(fin>>kind){
        if(kind=="Write"){
            fin>>kind;
            BaseProperty *ptr;
            if(kind=="Assistant")   ptr = new Assistant(fin);
            if(kind=="Teacher") ptr = new Teacher(fin);
            if(kind=="Master") ptr = new Master(fin);
            if(maps.count(ptr->getCardId())) {
                    flog<<"Sorry! ID : "<<ptr->getCardId()<<" HAS EXISTED!\n"<<endl; //��ѯ����,Ч��O(nlogn),Ҳ������hash,Ч��O(1)
                    continue;
            }
            maps.insert(make_pair(ptr->getCardId(),ptr));
            ptr->output(finfo);
        }
        if(kind=="Query"){
            int cardid;
            fin>>cardid;
            map<int,BaseProperty*>::iterator iter = maps.find(cardid);
            if(iter==maps.end()) flog<<"Sorry! ID : "<<cardid<<" NOT FOUND!\n"<<endl;
            else                 iter->second->output(flog);
        }
    }
    for(map<int,BaseProperty*>::iterator iter=maps.begin();iter!=maps.end();iter++)
        delete iter->second;
}

void Hits(){
    cout<<"Please Enter a number! 1 represents Command Input and 2 represents input from input.txt!"<<endl;
    cin>>iosin;
}

int main(){
    restart:Hits();
    if(iosin==2){
        ifstream fin("input.txt",ios::in);
        Solve(fin);
        cout<<"Please goto log.txt and info.txt to see the results\n";
    }
    else if(iosin==1) Solve(cin);
    else {
        cout<<"Please Enter 1 or 2 Please"<<endl;
        goto restart;
    }
    return 0;
}

#ifndef BASEP_H
#define BASEP_H

#include "Date.h"

#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define rep(i,n) for(int i=1;i<=n;i++)
class BaseProperty{
public:
    virtual void init(istream&);
    virtual void output(ostream&);
    BaseProperty(const string& id,istream& input):ID(id){
        init(input);
    }
    void setCardId(const int&);
    int getCardId() const;
    void setName(const string&);
    string getName()const;
    virtual ~BaseProperty(){}

private:
    int CardId;
    string name;
    Date birthday;
    string ID;
};

void BaseProperty::init(istream& input){
    int CI;string n;
    int y,m,d;
    input>>CI>>n>>y>>m>>d;
    birthday.setDate(m,d,y);
    setCardId(CI);
    setName(n);
}

void BaseProperty::output(ostream& out){
    out<<"===================Information Here==================="<<endl;
    out<<ID<<"CardId : "<<getCardId()<<"  Name is : "<<getName()<<"\nBirtyday is : "<<birthday<<endl;
}

void BaseProperty::setCardId(const int & CI){
    CardId = CI;
}

int BaseProperty::getCardId() const{
    return CardId;
}

void BaseProperty::setName(const string & n){
    name = n;
}

string BaseProperty::getName() const{
    return name;
}
#endif

#include "Polynomial.h"

Polynomial::Polynomial(){
    memset(dig,0,sizeof(dig));
    SetMP(0);
}

Polynomial::~Polynomial(){}

inline void Polynomial::Set(int ith,int value){
   dig[ith]=value;
   SetMP(max(GetMP(),ith));
}

inline int Polynomial::Get(int ith) const{
    return dig[ith];
}

ostream& operator << (ostream& output,Polynomial& A){
    for(int i=A.GetMP();i>=0;i--)
        if(A.dig[i]){
            if(i!=A.GetMP() && A.dig[i]>0) output<< " + ";
            output<<A.dig[i];
            if(i>1) output<<"x^"<<i;
            else if(i==1) output<<"x";
        }
    return output;
}

inline int Polynomial::GetMP() const{
    return MaxPower;
}

inline void Polynomial::SetMP(int MP){
    MaxPower = MP;
}

Polynomial Polynomial::operator + (const Polynomial& A) const{
    Polynomial ans;
    ans.SetMP(max(GetMP(),A.GetMP()));
    for(int i=0;i<=ans.MaxPower;i++)
        ans.Set(i,Get(i)+A.Get(i));
    return ans;
}

Polynomial Polynomial::operator - (const Polynomial& A) const{
    Polynomial ans;
    ans.SetMP(max(GetMP(),A.GetMP()));
    for(int i=0;i<=ans.MaxPower;i++)
        ans.Set(i,Get(i)-A.Get(i));
    int i = ans.GetMP();
    while(!ans.Get(i)) i--;
    ans.SetMP(i);
    return ans;
}

Polynomial Polynomial::operator * (const Polynomial& A) const{
    Polynomial ans;
    ans.SetMP(GetMP()+A.GetMP());
    for(int i=GetMP();i>=0;i--)
        if(Get(i))
            for(int j=A.GetMP();j>=0;j--)
                if(A.Get(j))
                    ans.Set(i+j,Get(i)*A.Get(j));
    return ans;
}

Polynomial Polynomial::operator = (const Polynomial& A){
    SetMP(A.GetMP());
    for(int i=0;i<=GetMP();i++)
        Set(i,A.Get(i));
    return *this;
}

Polynomial Polynomial::operator +=(const Polynomial& A){
    return *this = *this + A;
}

Polynomial Polynomial::operator -=(const Polynomial& A){
    return *this = *this - A;
}

Polynomial Polynomial::operator *=(const Polynomial& A){
    return *this = *this * A;
}









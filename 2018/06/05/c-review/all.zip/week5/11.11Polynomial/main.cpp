#include "Polynomial.h"

int main(){
    Polynomial A,B;
    A.Set(0,3);A.Set(1,5);A.Set(2,-3);
    B.Set(0,-4);B.Set(1,2);B.Set(3,4);
    cout<<"A is "<<A<<endl;
    cout<<"B is "<<B<<endl;
    Polynomial C;
    C= A + B;
    cout<<"A + B is " << C <<endl;
    C = A - B;
    cout<<"A - B is " << C <<endl;
    C = A * B;
    cout<<" A * B is " << C<<endl;
    A*=B;
    cout<<"A*=B is "<< A<<endl;
}

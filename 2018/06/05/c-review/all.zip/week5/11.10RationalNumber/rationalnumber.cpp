#include "RationalNumber.h"
#include<cstdio>
#include<iomanip>

inline int RationalNumber::GetGcd(int a,int b){
    return b?GetGcd(b, a%b):a;
}

inline void RationalNumber::f_std(int &n,int &d){
    if(d<0){
        d=-d;
        n=-n;
    }
    int gcd = GetGcd(n,d);
    n/=gcd;d/=gcd;
}

inline void RationalNumber::f_std(){
    int gcd = GetGcd(this->nume,this->deno);
    this->nume/=gcd;this->deno/=gcd;
    if(this->deno<0){
        this->deno*=-1;
        this->nume*=-1;
    }
}

inline RationalNumber::RationalNumber(int n,int d){
    if(!d){
        printf("deno can't be zero!\n");
        return ;
    }
    f_std(n,d);
    nume = n;deno = d;
}

inline RationalNumber RationalNumber::operator + (RationalNumber &A){
    RationalNumber ans;
    ans.nume = nume * A.deno + deno * A.nume;
    ans.deno = deno * A.deno;
    f_std(ans.nume,ans.deno);
    return ans;
}

inline RationalNumber RationalNumber::operator - (RationalNumber &A){
    RationalNumber ans;
    ans.nume = nume * A.deno - deno * A.nume;
    ans.deno = deno * A.deno;
    f_std(ans.nume,ans.deno);
    return ans;
}

inline RationalNumber RationalNumber::operator * (RationalNumber &A){
    RationalNumber ans;
    ans.nume = nume * A.nume;
    ans.deno = deno * A.deno;
    f_std(ans.nume,ans.deno);
    return ans;
}

inline RationalNumber RationalNumber::operator / (RationalNumber &A){
    RationalNumber ans;
    ans.nume = nume * A.deno;
    ans.deno = deno * A.nume;
    f_std(ans.nume,ans.deno);
    return ans;
}

inline ostream& operator << (ostream& output,RationalNumber& A){
    A.f_std();
    if(A.nume==0) puts("0");
    else if(A.nume>0){
        output<<setw(2)<<A.nume<<"\n--\n"
        <<setw(2)<<A.deno;
    }
    else{
        output<<setw(4)<<-A.nume<<"\n- --\n"
        <<setw(4)<<A.deno;
    }
    return output;
}

inline bool RationalNumber::operator == (RationalNumber& A){
    if(nume==A.nume && deno==A.deno) return true;
    return false;
}

inline bool RationalNumber::operator > (RationalNumber& A){
    double d_this = (double)nume/deno;
    double d_A = (double)A.nume/A.deno;
    return d_this > d_A;
}

inline bool RationalNumber::operator >= (RationalNumber& A){
    return (*this>A)||(*this==A);
}

inline bool RationalNumber::operator <= (RationalNumber& A){
    return !(*this>A);
}

inline bool RationalNumber::operator < (RationalNumber& A){
    return !(*this >= A);
}

inline bool RationalNumber::operator != (RationalNumber& A){
    return !(*this==A);
}

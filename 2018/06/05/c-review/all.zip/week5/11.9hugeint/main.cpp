#include <iostream>
#include "Hugeint.h"
using namespace std;

int main(){
    HugeInt n1(7654321);
    HugeInt n2(7891234);
    HugeInt n3("99999999999999999999999999999");
    HugeInt n4("1");
    HugeInt n5("71117123");
    HugeInt n6("21317");
    if(n1==n2)  cout<<"n1 is equal to n2!"<<endl;
    else        cout<<"n1 isn't equal to n2!"<<endl;
    cout<<n1<<'+'<<n2<<"="<<n1+n2<<endl;
    cout<<n3<<'-'<<n2<<'='<<n3-n2<<endl;
    cout<<n1<<'-'<<n2<<'='<<n1-n2<<endl;
    cout<<n5<<'/'<<n6<<'='<<n5/n6<<endl;
    cout<<n5<<'*'<<n6<<'='<<n5*n6<<endl;
    return 0;
}

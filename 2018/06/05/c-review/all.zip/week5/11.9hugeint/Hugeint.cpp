#include<iostream>
#include<cstring>
#include "Hugeint.h"
using namespace std;

HugeInt::HugeInt(int value){
    negative = false;
    for (int i=0;i<lens;i++) dig[i] = 0;
    for (int i = lens - 1; value != 0 && i >= 0; i--){
        dig[i] = value % 10;
        value /= 10;
    }
}

HugeInt::HugeInt(const string &number){
    negative = false;
    memset(dig,0,sizeof(dig));
    int len = number.size();
    for (int i = lens - len, j = 0; i < lens; i++, j++)
      if (isdigit(number[j])) dig[i] = number[j] - '0';

}

int HugeInt::getLength()const{
    int i;
    for (i = 0; i < lens; i++)
        if (dig[i]!= 0) break;
    return lens - i;
}

HugeInt HugeInt::operator+(const HugeInt &op2) const{
    HugeInt temp;
    int carry = 0;
    for (int i = lens - 1; i >= 0; i--){
        temp.dig[i] = dig[i] + op2.dig[i] + carry;
        if (temp.dig[i] > 9){
            temp.dig[i] %= 10;
            carry = 1;
        }
        else
        carry = 0;
    }
    return temp;
}

HugeInt HugeInt::operator+(int op2) const{
    return *this + HugeInt(op2);
}

HugeInt HugeInt::operator+(const string &op2) const{
    return *this + HugeInt(op2);
}

bool HugeInt::operator==(const HugeInt &op2) const{
    for (int i = 0; i < lens; i++)
        if (op2.dig[i] != dig[i])
            return false;
    return true;
}

bool HugeInt::operator!=(const HugeInt &op2) const{
    return !(*this == op2);
}

bool HugeInt::operator<(const HugeInt &op2) const{
    for (int i = 0; i < lens; i++){
        if (dig[i] == op2.dig[i])   continue;
        else if (dig[i] > op2.dig[i])   return false;
        else  return true;
    }
    return false;
}

bool HugeInt::operator<=(const HugeInt &op2) const{
    return !(*this > op2);
}

bool HugeInt::operator>(const HugeInt &op2) const{
    return op2 < *this;
}

bool HugeInt::operator>=(const HugeInt &op2) const{
    return !(*this < op2);
}

ostream& operator<<(ostream &output, const HugeInt &num){
    int i;
    if(num.negative) output<<'-';
    for (i = 0; i < HugeInt::lens && num.dig[i] == 0; i++);
    if (i == HugeInt::lens)    output << 0;
    else
        for (; i < HugeInt::lens; i++)
            output << num.dig[i];

    return output;
}
// -------------modified by textbook Fig11.16-11.18-----------------------
HugeInt HugeInt::operator-(const HugeInt &A) const{
    if (A > *this){
        HugeInt result("0"); //��������
        result = A - *this;
        result.negative = true;
        return result;
   }
    HugeInt result("0");
    for(int i=lens-1;i>=0;i--){
        result.dig[i]+=this->dig[i]-A.dig[i];
        if(result.dig[i]<0){//��λ
            result.dig[i-1]-=1;
            result.dig[i]+=10;
        }
    }
    return result;
}

HugeInt HugeInt::operator*(const HugeInt &A) const{
    int JW = 0;
    HugeInt ANS("0");
    HugeInt small = (*this < A) ? *this : A;
    HugeInt big = (*this > A) ? *this : A;
    int x=0;
    while(x<lens && !big.dig[x]) x++;
    int heads = x;
    for (int i = lens; i > lens - small.getLength(); i--){ //��big��ÿһλ����small
        HugeInt CInt("0");
        int nextLoc = i - 1;
        for (int j = lens; j > lens - big.getLength(); j--){
            int CResult = JW +(big.dig[j-1] * small.dig[i-1]); //��ǰ��˼��Ͻ�λ
            if (j-1 == heads){
                JW = 0;
                CInt.dig[nextLoc] =CResult % 10;//��λ
                nextLoc -= 1;
                CInt.dig[nextLoc] =CResult / 10;//ʮλ
                nextLoc -= 1;
            }
            else{
                JW = CResult / 10;
                CInt.dig[nextLoc] = CResult % 10;
                nextLoc -= 1;
            }
        }
        ANS = ANS + CInt;
    }
    return ANS;
}

HugeInt HugeInt::operator/(const HugeInt &A) const{
    HugeInt remains(*this);
    HugeInt CValue("0"),result("0");
    int mLen = this->getLength();
    for (int i = lens - mLen; i < lens; i++){
        CValue = CValue * HugeInt("10");
        CValue.dig[lens-1] = remains.dig[i];
        HugeInt tResult("0");
        if (A > CValue) result.dig[i] = 0;
        else{
            int j=1;
            for (;j<=10;j++){
                HugeInt tPro = A * HugeInt(j);
                if (tPro > CValue) break;
            }
            result.dig[i] = j-1;
            tResult = A * HugeInt(j-1);
        }
        CValue = CValue - tResult;
    }
    return result;
}

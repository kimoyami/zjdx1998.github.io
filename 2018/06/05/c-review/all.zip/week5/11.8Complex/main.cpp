#include"complex.cpp"
#include<iostream>
using namespace std;
int main(){
    Complex A,B,C;
    cin>>A>>B;
    C = A + B;
    cout<<C<<endl;
    cout<<A-B<<endl;
    C = A * B;
    cout<<C<<endl;
    return 0;
}

#include "complex.h"

inline Complex Complex::operator - (const Complex& A) const{
    Complex ans;
    ans.real = real - A.real;
    ans.imagin = imagin - A.imagin;
    return ans;
}

inline Complex Complex::operator + (const Complex& A) const{
    Complex ans;
    ans.real = real + A.real;
    ans.imagin = imagin + A.imagin;
    return ans;
}

inline bool Complex::operator == (const Complex& A) const{
    if(real!=A.real||imagin!=A.imagin) return false;
    return true;
}

inline bool Complex::operator != (const Complex& A) const{
    if(real==A.real && imagin==A.imagin) return false;
    return true;
}

inline Complex Complex::operator * (const Complex& A) const{
    Complex ans;
    ans.real = real*A.real - imagin*A.imagin;
    ans.imagin = real*A.imagin + imagin*A.real;
    return ans;
}

inline istream& operator >>(istream& input,Complex& A){
    char ch,ch0;
    input >> A.real >> ch >> A.imagin>>ch0;
    if(ch=='-') A.imagin*=-1;
    return input;
}

inline ostream& operator <<(ostream& output,const Complex& A){
    output << setprecision(3) << A.real;
    if(A.imagin){
        if(A.imagin>0) output << setw(3) << '+';
        else           output << setw(3) << '-';
        output << setprecision(3) << setw(3) << abs(A.imagin) << 'i';
    }
    return output;
}

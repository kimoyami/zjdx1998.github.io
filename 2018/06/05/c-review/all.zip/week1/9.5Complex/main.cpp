#include"complex.h"
#include"complex.cpp"
#include<iostream>
using namespace std;
int main(){
    Complex A(5,3),B(6,1);
    Complex C = A - B;
    C.Print();
    return 0;
}
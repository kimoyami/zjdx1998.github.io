class Complex{
public:
    Complex(double r,double i):real(r),imagin(i){};
    void Add(double r,double i);
    Complex operator - (Complex &A);
    Complex operator + (Complex &A);
    void Print();
private:
    double real,imagin;
};
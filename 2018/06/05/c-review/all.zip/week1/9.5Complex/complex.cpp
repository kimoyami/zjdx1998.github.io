#include<cstdio>

Complex Complex::operator - (Complex &A){
    Complex ans;
    ans.real = real - A.real;
    ans.imagin = imagin - A.imagin;
    return ans;
}

Complex Complex::operator + (Complex &A){
    Complex ans;
    ans.real = real + A.real;
    ans.imagin = imagin + A.imagin;
    return ans;
}


void Complex::Print(){
    printf("%.3lf",real);
    if(imagin>0) printf(" + %.3lfi\n",imagin);
    else         printf(" - %.3lfi\n",-imagin);
}
    
#ifndef MYTIME_CPP
#define MYTIME_CPP
#include<cstdio>
#include<iomanip>
#include<iostream>
using namespace std;
#endif

Time::Time(int hour,int minute,int second){
    setTime(hour,minute,second);
}

void Time::setTime(int hour,int minute,int second){
    setHour(hour,0);
    setMinute(minute,0);
    setSecond(second,0);
}

void Time::setHour(int hour,int flag){
    if(0<=hour && hour<=23) this->hour = hour;
    else if(!flag){
        puts("hour must between 0 and 23");
        return;
    }
    else this->hour = 0;
}

void Time::setMinute(int minute,int flag){
    if(0<=minute && minute<=59) this->minute = minute;
    else if(!flag){
        puts("minute must between 0 and 59");
        return;
    }
    else{
        this->minute = 0;
        setHour(hour+1,1);
    }
}

void Time::setSecond(int second,int flag){
    if(0<=second && second<=59) this->second = second;
    else if(!flag){
        puts("second must between 0 and 59");
        return;
    }
    else{
        this->second = 0;
        setMinute(minute+1,1);
    }
}

int Time::getHour(){
    return hour; 
}

int Time::getMinute(){
    return minute;
}

int Time::getSecond(){
    return second; 
}

void Time::print_nor(){//(HH:MM:SS)
    cout<< setfill('0')<<setw(2)<<getHour()<<":"
        << setw(2)<<getMinute()<<":"<<setw(2)<<getSecond();
    cout<<endl;
}

void Time::print_std(){//HH:MM:SS AM or PM
    cout << ( (hour==0) || (hour==12 ) ? 12 : hour%12)<<":"
         << setfill('0')<<setw(2)<<getMinute()<<":"<<setw(2)
         <<getSecond()<< (hour < 12 ? "AM" : "PM");
    cout<<endl;
}

void Time::tick(){
    setSecond(second+1,1);
}


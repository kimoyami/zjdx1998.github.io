class Time{
public:
    Time(int=0,int=0,int=0);
    void setTime(int,int,int);
    void setHour(int,int);
    void setMinute(int,int);
    void setSecond(int,int);
    int getHour();
    int getMinute();
    int getSecond();
    void print_nor();
    void print_std();
    void tick();
private:
    int hour,minute,second;
};
#include "fraction.h"
#include "fraction.cpp"
#include <cstdio>
#include <cstdlib>
#include <iostream>
using namespace std;

int main(){
    fraction A(5,6),B(3,4);
    fraction C = A - B;
    C.Print();
    return 0;
}
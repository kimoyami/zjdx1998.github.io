#ifndef FLAG_STDIO
#define FLAG_STDIO
#include<cstdio>
#endif

int fraction::GetGcd(int a,int b){
    return b?GetGcd(b, a%b):a;
}

void fraction::f_std(int &n,int &d){
    if(d % n == 0){
        int gcd = GetGcd(n,d);
        n/=gcd;d/=gcd;
    }
}

fraction::fraction(int n,int d){
    if(!d){
        printf("该分数不合法!");
        return ;
    }
    f_std(n,d);
    nume = n;deno = d;
}

fraction fraction::operator + (fraction &A){
    fraction ans;
    ans.nume = nume * A.deno + deno * A.nume;
    ans.deno = deno * A.deno;
    f_std(ans.nume,ans.deno);
    return ans;
}

fraction fraction::operator - (fraction &A){
    fraction ans;
    ans.nume = nume * A.deno - deno * A.nume;
    ans.deno = deno * A.deno;
    f_std(ans.nume,ans.deno);
    return ans;
}

fraction fraction::operator * (fraction &A){
    fraction ans; 
    ans.nume = nume * A.nume;
    ans.deno = deno * A.deno;
    f_std(ans.nume,ans.deno);
    return ans;
}

fraction fraction::operator / (fraction &A){
    fraction ans;
    ans.nume = nume * A.deno;
    ans.deno = deno * A.nume;
    f_std(ans.nume,ans.deno);
    return ans;
}

void fraction::Print(){
    f_std(nume,deno);
    printf("%3d\n --\n%3d\n",nume,deno);
    return;
}


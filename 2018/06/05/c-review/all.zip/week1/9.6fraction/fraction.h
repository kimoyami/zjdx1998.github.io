class fraction{
public:
    fraction():nume(0),deno(1){};
    fraction(int n,int d);
    fraction operator + (fraction &A);
    fraction operator - (fraction &A);
    fraction operator * (fraction &A);
    fraction operator / (fraction &A);
    void Print();
    
private:
    int nume,deno;
    int GetGcd(int a,int b);
    void f_std(int &a,int &b);
};
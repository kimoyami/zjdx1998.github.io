//负数处理被我复杂化了
#ifndef hugeint_CPP
#define hugeint_CPP
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#endif

hugeint::hugeint(){
    len = 0;
    memset(dig,0,sizeof(dig));
}

void hugeint::input(){
    memset(dig,0,sizeof(dig));
    char str[50];
    scanf("%s",str);
    len = strlen(str);
    for(int i=0;i<len;i++)
       dig[len-i]=str[i]-'0';
    if(dig[len]=='-'-'0') len--;
}

void hugeint::output(){
    printf("%d",dig[len]);
    for(int i=len-1;i>=1;i--) printf("%d",abs(dig[i]));
    printf("\n");
}

bool hugeint::operator == (hugeint &B){
    if(len!=B.len) return false;
    for(int i=1;i<=len;i++)
        if(dig[i]!=B.dig[i]) return false;
    return true;
}

bool hugeint::operator > (hugeint &B){
    if(len<B.len) return false;
    if(len>B.len) return true;
    for(int i=len;i>=1;i--)
        if(dig[i]<B.dig[i]) return false;
    if(dig[1]==B.dig[1]) return false;
    return true;
}

bool hugeint::operator < (hugeint &B){
    if(len>B.len) return false;
    if(len<B.len) return true;
    for(int i=len;i>=1;i++)
        if(dig[i]>B.dig[i]) return false;
    if(dig[len]==B.dig[len]) return false;
    return true;
}

bool hugeint::operator != (hugeint &B){
    if(*this==B) return false;
    else        return true;
}

bool hugeint::operator >= (hugeint &B){
    if(len<B.len) return false;
    if(len>B.len) return true;
    for(int i=len;i>=1;i--)
        if(dig[i]<B.dig[i]) return false;
    return true;
}

bool hugeint::operator <= (hugeint &B){
    if(len>B.len) return false;
    if(len<B.len) return true;
    for(int i=len;i>=1;i--)
        if(dig[i]>B.dig[i]) return false;
    return true;
}

hugeint hugeint::add(hugeint B){
    if(B.dig[B.len+1]=='-'-'0'){
        B.dig[B.len+1]=0;
        return sub(B);
    }
    if(dig[len+1]=='-'-'0'){
        dig[len+1]=0;
        return B.sub(*this);
    }
    hugeint ans;
    ans.len = max(this->len,B.len);
    for(int i=1;i<=ans.len;i++){
        ans.dig[i]+=dig[i]+B.dig[i];
        ans.dig[i+1]+=ans.dig[i]/10;
        ans.dig[i]%=10;
    }
    if(ans.dig[ans.len+1]) ans.len++;
    while(!ans.dig[ans.len] && (ans.len>1) ) ans.len--;
    return ans;
}

hugeint hugeint::sub(hugeint B){
    if(B.dig[B.len+1]=='-'-'0'){
        B.dig[B.len+1]=0;
        if(dig[len+1]=='-'-'0'){
            dig[len+1]=0;
            return B.sub(*this);
        }
        return add(B);
    }
    if(dig[len+1]=='-'-'0'){
        for(int i=1;i<=len;i++) dig[i]*=-1;
        dig[len+1]=0;
    }
    hugeint ans;
    if(len>B.len||((len==B.len)&& dig[len]>B.dig[len])){
        ans.len = len;
        for(int i=1;i<=len;i++){
            ans.dig[i]+=dig[i]-B.dig[i];
            if(ans.dig[i]<0 && i<len &&ans.dig[i+1]>0){
                ans.dig[i]+=10;
                ans.dig[i+1]-=1;
            }
        }
        while(!ans.dig[ans.len] && (ans.len>1) ) ans.len--;
        return ans;
    }
    else{
        ans.len = B.len;
        for(int i=1;i<=ans.len;i++){
            ans.dig[i]+=B.dig[i]-dig[i];
            if(ans.dig[i]<0){
                ans.dig[i]+=10;
                ans.dig[i+1]-=1;
            }
        }
        while(!ans.dig[ans.len] && (ans.len>1) ) ans.len--;
        ans.dig[ans.len]*=-1;
        return ans;
    }
}
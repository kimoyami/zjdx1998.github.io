#include "hugeint.h"
#include "hugeint.cpp"

int main(){
    hugeint A,B;
    printf("please enter two numbers!\n");
    A.input();
    B.input();
    printf("substract test:\n");
    hugeint C = A.sub(B);
    C.output();
    printf("please enter two numbers!\n");
    A.input();
    B.input();
    C = A.add(B);
    printf("add test:\n");
    C.output();
    return 0;
}
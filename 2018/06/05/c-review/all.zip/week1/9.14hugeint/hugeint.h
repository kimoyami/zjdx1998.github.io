class hugeint{
public:
    hugeint();
    void input();
    void output();
    hugeint add(hugeint);
    hugeint sub(hugeint);
    bool operator == (hugeint &B);
    bool operator != (hugeint &B);
    bool operator > (hugeint &B);
    bool operator < (hugeint &B);
    bool operator >= (hugeint &B);
    bool operator <= (hugeint &B);
private:
    int len,dig[50];
};